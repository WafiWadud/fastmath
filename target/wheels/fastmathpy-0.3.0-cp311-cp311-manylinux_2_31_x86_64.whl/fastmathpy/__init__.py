from .fastmathpy import *

__doc__ = fastmathpy.__doc__
if hasattr(fastmathpy, "__all__"):
    __all__ = fastmathpy.__all__